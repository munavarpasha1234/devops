#!/bin/bash

#This the second script we are executig

NAME=Jhon

echo Hi $NAME
echo Good Morning $NAME
echo Good Night $NAME