#!/bin/bash

#DATE=2018-11-01
DATE=$(date +%F)
echo Hi, welcome today date is $DATE