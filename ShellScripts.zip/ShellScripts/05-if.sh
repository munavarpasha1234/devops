#!/bin/bash

echo "Checking the if statement"

A=10
B=10

if [ $A -eq $B ]; then
	echo "Inside if, because the condition is true"
fi